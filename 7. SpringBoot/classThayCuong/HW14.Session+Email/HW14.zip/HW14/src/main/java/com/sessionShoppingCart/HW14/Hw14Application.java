package com.sessionShoppingCart.HW14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw14Application {

	public static void main(String[] args) {
		SpringApplication.run(Hw14Application.class, args);
	}

}
